package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.memory.ArchanaDatabase
import com.example.memory.MemoryRepository
import com.example.phone.CommandResult
import com.example.phone.PhoneActionHandler
import com.example.settings.AssistantMode
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Archana AI", appName)
    }

    @Test
    fun testPhoneActionHandlerOpenWhatsApp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val handler = PhoneActionHandler(context)
        val result = handler.tryHandleCommand("WhatsApp kholo", "Sir")
        assertTrue(result is CommandResult.Executed)
        val executed = result as CommandResult.Executed
        assertTrue(executed.speechResponse.contains("WhatsApp"))
    }

    @Test
    fun testPhoneActionHandlerCall() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val handler = PhoneActionHandler(context)
        val result = handler.tryHandleCommand("Call 9876543210", "Sir")
        assertTrue(result is CommandResult.NeedsAction)
    }

    @Test
    fun testArchanaIdentityResponses() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = ArchanaDatabase.getInstance(context)
        val repo = MemoryRepository(db.archanaDao())
        val aiService = com.example.ai.ArchanaAiService(context, repo)

        runBlocking {
            val creatorResponse = aiService.getAssistantResponse(
                userMessage = "Aapko kisne banaya?",
                mode = AssistantMode.FRIENDLY,
                userName = "Sir"
            )
            assertEquals("Mujhe Ashan Sir ne banaya hai.", creatorResponse)

            val ashanInfo = aiService.getAssistantResponse(
                userMessage = "Ashan Sir kaun hain?",
                mode = AssistantMode.FRIENDLY,
                userName = "Sir"
            )
            assertEquals(
                "Ashan Sir mere developer hain. Unhone mujhe develop kiya hai aur mujhe Android phone par users ki madad karne ke liye banaya hai.",
                ashanInfo
            )

            val wakeResponse = aiService.getAssistantResponse(
                userMessage = "Archana",
                mode = AssistantMode.FRIENDLY,
                userName = "Sir"
            )
            assertEquals("Boliye Sir, kya hua? Kya madad kar sakun?", wakeResponse)
        }
    }
}
