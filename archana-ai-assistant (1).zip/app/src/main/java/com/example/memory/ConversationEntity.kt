package com.example.memory

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "user" or "archana"
    val message: String,
    val mode: String = "normal",
    val timestamp: Long = System.currentTimeMillis()
)
