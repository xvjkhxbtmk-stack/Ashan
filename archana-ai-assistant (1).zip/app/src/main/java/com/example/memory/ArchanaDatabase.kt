package com.example.memory

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MemoryEntity::class, ConversationEntity::class], version = 1, exportSchema = false)
abstract class ArchanaDatabase : RoomDatabase() {
    abstract fun archanaDao(): ArchanaDao

    companion object {
        @Volatile
        private var INSTANCE: ArchanaDatabase? = null

        fun getInstance(context: Context): ArchanaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ArchanaDatabase::class.java,
                    "archana_ai.db"
                ).fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
