package com.example.memory

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class MemoryRepository(private val dao: ArchanaDao) {
    val memories: Flow<List<MemoryEntity>> = dao.getAllMemories()
    val conversations: Flow<List<ConversationEntity>> = dao.getAllConversations()

    suspend fun saveMemory(key: String, value: String, category: String = "general") {
        dao.insertMemory(MemoryEntity(key = key, value = value, category = category))
    }

    suspend fun deleteMemory(id: Long) {
        dao.deleteMemory(id)
    }

    suspend fun clearAllMemories() {
        dao.clearAllMemories()
    }

    suspend fun recordMessage(sender: String, message: String, mode: String) {
        dao.insertConversation(ConversationEntity(sender = sender, message = message, mode = mode))
    }

    suspend fun clearAllConversations() {
        dao.clearAllConversations()
    }

    suspend fun buildMemoryContextPrompt(): String {
        val list = memories.firstOrNull().orEmpty()
        if (list.isEmpty()) return ""
        val builder = StringBuilder("User's remembered facts & preferences:\n")
        list.forEach { memory ->
            builder.append("- ${memory.key}: ${memory.value}\n")
        }
        return builder.toString()
    }
}
