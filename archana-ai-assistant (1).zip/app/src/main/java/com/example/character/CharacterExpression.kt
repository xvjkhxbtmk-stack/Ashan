package com.example.character

enum class CharacterExpression {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    HAPPY,
    AFFECTIONATE,
    SURPRISED
}
