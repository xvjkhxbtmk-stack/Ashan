package com.example.character

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.settings.AssistantMode
import kotlinx.coroutines.delay
import kotlin.math.sin

@Composable
fun ArchanaCharacterView(
    modifier: Modifier = Modifier,
    expression: CharacterExpression,
    assistantMode: AssistantMode,
    isSpeaking: Boolean,
    speakingAmplitude: Float,
    isListening: Boolean,
    listeningRms: Float,
    onCharacterTap: () -> Unit = {}
) {
    // 1. Natural blinking cycle
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay((2800..4500).random().toLong())
            isBlinking = true
            delay(130)
            isBlinking = false
        }
    }

    // 2. Idle subtle breathing & bobbing animation
    val infiniteTransition = rememberInfiniteTransition(label = "archana_idle")
    val breathingOffset by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing"
    )

    // 3. Cyber holographic halo rotation
    val haloRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "halo_rotation"
    )

    // Dynamic aura colors
    val auraColor = when {
        isSpeaking -> Color(0xFFE040FB) // Vivid violet/pink
        isListening -> Color(0xFF00E5FF) // Cyber cyan
        assistantMode == AssistantMode.GIRLFRIEND -> Color(0xFFFF4081) // Sweet rose
        expression == CharacterExpression.THINKING -> Color(0xFFFFD700) // Golden amber
        else -> Color(0xFF7C4DFF) // Purple
    }

    val dynamicPulse = if (isSpeaking) {
        (speakingAmplitude * 18f).coerceIn(4f, 26f)
    } else if (isListening) {
        (listeningRms * 20f).coerceIn(3f, 24f)
    } else {
        4f
    }

    Box(
        modifier = modifier
            .testTag("archana_character_view")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                onCharacterTap()
            },
        contentAlignment = Alignment.Center
    ) {
        // Holographic Aura Canvas (Audio Waves & Sci-Fi Ring)
        Canvas(modifier = Modifier.size(260.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.width * 0.44f

            // Outer reactive audio ripple ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(auraColor.copy(alpha = 0.35f), Color.Transparent),
                    center = center,
                    radius = baseRadius + dynamicPulse + 20f
                ),
                radius = baseRadius + dynamicPulse + 16f
            )

            // Sci-fi segmented halo ring
            val ringStroke = Stroke(width = 3.dp.toPx())
            drawCircle(
                color = auraColor.copy(alpha = 0.8f),
                radius = baseRadius + 6f,
                style = ringStroke
            )

            // Rotating cyber tick nodes
            val tickCount = 8
            for (i in 0 until tickCount) {
                val angle = Math.toRadians((haloRotation + (i * 360f / tickCount)).toDouble())
                val x = center.x + (baseRadius + 6f) * Math.cos(angle).toFloat()
                val y = center.y + (baseRadius + 6f) * Math.sin(angle).toFloat()
                drawCircle(
                    color = auraColor,
                    radius = if (i % 2 == 0) 4.5f else 2.5f,
                    center = Offset(x, y)
                )
            }
        }

        // Anime Avatar Container with breathing offset
        Box(
            modifier = Modifier
                .offset { IntOffset(0, breathingOffset.toInt()) }
                .size(190.dp)
                .shadow(
                    elevation = 20.dp,
                    shape = CircleShape,
                    spotColor = auraColor,
                    ambientColor = auraColor
                )
                .clip(CircleShape)
                .border(3.dp, Brush.linearGradient(listOf(auraColor, Color(0xFF00E5FF))), CircleShape)
                .background(Color(0xFF130924)),
            contentAlignment = Alignment.Center
        ) {
            // High-res Anime Portrait
            Image(
                painter = painterResource(id = R.drawable.archana_avatar),
                contentDescription = "Archana Anime AI Assistant",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dynamic Face Expression Layer (Blinking, Lip-sync, and Blush Overlay)
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // 1. Anime Blush (Cheeks)
                val blushAlpha = when {
                    assistantMode == AssistantMode.GIRLFRIEND -> 0.55f
                    expression == CharacterExpression.HAPPY || expression == CharacterExpression.AFFECTIONATE -> 0.45f
                    isSpeaking -> 0.35f
                    else -> 0.20f
                }
                // Left cheek blush
                drawCircle(
                    color = Color(0xFFFF5252).copy(alpha = blushAlpha),
                    radius = w * 0.08f,
                    center = Offset(w * 0.33f, h * 0.62f)
                )
                // Right cheek blush
                drawCircle(
                    color = Color(0xFFFF5252).copy(alpha = blushAlpha),
                    radius = w * 0.08f,
                    center = Offset(w * 0.67f, h * 0.62f)
                )

                // 2. Natural Blinking Overlay
                if (isBlinking) {
                    // Closed eyelids (smooth anime curve lines)
                    val stroke = Stroke(width = 3.5.dp.toPx())
                    // Left eye closed line
                    drawLine(
                        color = Color(0xFF231435),
                        start = Offset(w * 0.30f, h * 0.52f),
                        end = Offset(w * 0.44f, h * 0.52f),
                        strokeWidth = stroke.width
                    )
                    // Right eye closed line
                    drawLine(
                        color = Color(0xFF231435),
                        start = Offset(w * 0.56f, h * 0.52f),
                        end = Offset(w * 0.70f, h * 0.52f),
                        strokeWidth = stroke.width
                    )
                }

                // 3. Dynamic Lip-Sync Mouth Opening
                if (isSpeaking) {
                    val mouthOpenScale = (speakingAmplitude * 1.3f).coerceIn(0.2f, 1.0f)
                    val mouthHeight = (h * 0.045f) * mouthOpenScale
                    val mouthWidth = (w * 0.09f)

                    // Speaking mouth cavity
                    drawOval(
                        color = Color(0xFFE91E63),
                        topLeft = Offset(w * 0.5f - (mouthWidth / 2f), h * 0.72f - (mouthHeight / 2f)),
                        size = androidx.compose.ui.geometry.Size(mouthWidth, mouthHeight.coerceAtLeast(3f))
                    )
                    // Upper teeth hint
                    drawOval(
                        color = Color.White.copy(alpha = 0.9f),
                        topLeft = Offset(w * 0.5f - (mouthWidth * 0.35f), h * 0.72f - (mouthHeight / 2f)),
                        size = androidx.compose.ui.geometry.Size(mouthWidth * 0.7f, (mouthHeight * 0.4f).coerceAtLeast(1.5f))
                    )
                }
            }
        }

        // Mode / Expression Badge at Bottom of Avatar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 14.dp)
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color(0xFF1E1035), Color(0xFF0F2038))
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                .border(1.dp, auraColor.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            val statusLabel = when {
                isSpeaking -> "Speaking..."
                isListening -> "Listening..."
                expression == CharacterExpression.THINKING -> "Thinking..."
                assistantMode == AssistantMode.GIRLFRIEND -> "Archana • Caring"
                assistantMode == AssistantMode.FRIENDLY -> "Archana • Friendly"
                assistantMode == AssistantMode.PROFESSIONAL -> "Archana • Pro"
                assistantMode == AssistantMode.SILENT -> "Archana • Silent"
                else -> "Archana AI"
            }
            Text(
                text = statusLabel,
                color = auraColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}
