package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

class ArchanaTtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _speakingAmplitude = MutableStateFlow(0f)
    val speakingAmplitude: StateFlow<Float> = _speakingAmplitude.asStateFlow()

    private var amplitudeJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    var pitch: Float = 1.25f
        set(value) {
            field = value
            tts?.setPitch(value)
        }

    var speed: Float = 1.0f
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    var onSpeechComplete: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            // Prefer Hindi or US English fallback
            val hiLocale = Locale.forLanguageTag("hi-IN")
            val available = tts?.isLanguageAvailable(hiLocale)
            if (available != TextToSpeech.LANG_NOT_SUPPORTED && available != TextToSpeech.LANG_MISSING_DATA) {
                tts?.language = hiLocale
            } else {
                tts?.language = Locale.US
            }
            tts?.setPitch(pitch)
            tts?.setSpeechRate(speed)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                    startAmplitudeSimulation()
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    stopAmplitudeSimulation()
                    onSpeechComplete?.invoke()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    stopAmplitudeSimulation()
                }
            })
        }
    }

    fun speak(text: String, flush: Boolean = true) {
        if (!isInitialized || text.isBlank()) return
        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val utteranceId = UUID.randomUUID().toString()
        tts?.speak(text, queueMode, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        stopAmplitudeSimulation()
    }

    private fun startAmplitudeSimulation() {
        amplitudeJob?.cancel()
        amplitudeJob = scope.launch {
            while (_isSpeaking.value) {
                // Natural speech oscillation between 0.2 and 1.0 for lip-sync
                val amp = (0.3f + Math.sin(System.currentTimeMillis() / 80.0).toFloat() * 0.4f +
                        (Math.random().toFloat() * 0.3f)).coerceIn(0.1f, 1.0f)
                _speakingAmplitude.value = amp
                delay(60)
            }
            _speakingAmplitude.value = 0f
        }
    }

    private fun stopAmplitudeSimulation() {
        amplitudeJob?.cancel()
        amplitudeJob = null
        _speakingAmplitude.value = 0f
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
