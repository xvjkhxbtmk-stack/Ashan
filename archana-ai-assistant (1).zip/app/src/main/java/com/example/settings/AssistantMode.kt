package com.example.settings

enum class AssistantMode(val title: String, val description: String) {
    NORMAL(
        title = "Normal Mode",
        description = "Polite, helpful and balanced AI assistant."
    ),
    FRIENDLY(
        title = "Friendly Mode",
        description = "Cheerful, warm and expressive anime friend."
    ),
    GIRLFRIEND(
        title = "Girlfriend-style Mode",
        description = "Affectionate, caring, asking if you ate, attentive and sweet. Completely safe."
    ),
    PROFESSIONAL(
        title = "Professional Mode",
        description = "Concise, formal, direct and efficient."
    ),
    SILENT(
        title = "Silent Mode",
        description = "Text-only responses without audio speech synthesis."
    );

    companion object {
        fun fromName(name: String): AssistantMode {
            return entries.find { it.name.equals(name, ignoreCase = true) } ?: NORMAL
        }
    }
}
