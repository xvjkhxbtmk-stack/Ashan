package com.example.settings

import android.content.Context
import android.content.SharedPreferences

class ArchanaPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("archana_prefs", Context.MODE_PRIVATE)

    var mode: AssistantMode
        get() = AssistantMode.fromName(prefs.getString("mode", AssistantMode.FRIENDLY.name) ?: AssistantMode.FRIENDLY.name)
        set(value) = prefs.edit().putString("mode", value.name).apply()

    var isWakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_word_enabled", true)
        set(value) = prefs.edit().putBoolean("wake_word_enabled", value).apply()

    var isFloatingOverlayEnabled: Boolean
        get() = prefs.getBoolean("floating_overlay_enabled", false)
        set(value) = prefs.edit().putBoolean("floating_overlay_enabled", value).apply()

    var isContinuousListeningEnabled: Boolean
        get() = prefs.getBoolean("continuous_listening", false)
        set(value) = prefs.edit().putBoolean("continuous_listening", value).apply()

    var ttsPitch: Float
        get() = prefs.getFloat("tts_pitch", 1.25f)
        set(value) = prefs.edit().putFloat("tts_pitch", value).apply()

    var ttsSpeed: Float
        get() = prefs.getFloat("tts_speed", 1.0f)
        set(value) = prefs.edit().putFloat("tts_speed", value).apply()

    var userName: String
        get() = prefs.getString("user_name", "Sir") ?: "Sir"
        set(value) = prefs.edit().putString("user_name", value).apply()
}
