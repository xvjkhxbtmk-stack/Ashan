package com.example.phone

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast

sealed class CommandResult {
    data class Executed(val speechResponse: String) : CommandResult()
    data class NeedsPermission(val permission: String, val reason: String) : CommandResult()
    data class NeedsAction(val message: String, val actionIntent: Intent) : CommandResult()
    data object NotHandled : CommandResult()
}

class PhoneActionHandler(private val context: Context) {

    private val cameraManager: CameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    }

    private var isTorchOn: Boolean = false

    fun tryHandleCommand(commandText: String, userName: String): CommandResult {
        val lower = commandText.trim().lowercase()

        // 1. WhatsApp
        if (lower.contains("whatsapp") && (lower.contains("khol") || lower.contains("open"))) {
            return openApp("com.whatsapp", "WhatsApp", "WhatsApp khol rahi hoon $userName!")
        }

        // 2. Instagram
        if (lower.contains("instagram") && (lower.contains("khol") || lower.contains("open"))) {
            return openApp("com.instagram.android", "Instagram", "Instagram khol rahi hoon $userName!")
        }

        // 3. YouTube
        if (lower.contains("youtube") && (lower.contains("khol") || lower.contains("open"))) {
            return openApp("com.google.android.youtube", "YouTube", "YouTube khol rahi hoon $userName!")
        }

        // 4. Chrome
        if (lower.contains("chrome") && (lower.contains("khol") || lower.contains("open"))) {
            return openApp("com.android.chrome", "Chrome", "Chrome browser khol rahi hoon $userName!")
        }

        // 5. Camera
        if (lower.contains("camera") && (lower.contains("khol") || lower.contains("open") || lower.contains("chalu"))) {
            return try {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                CommandResult.Executed("Camera open ho gaya hai $userName.")
            } catch (e: Exception) {
                CommandResult.Executed("Camera kholne mein samasya aayi.")
            }
        }

        // 6. Flashlight
        if (lower.contains("flashlight") || lower.contains("torch")) {
            val turnOn = lower.contains("on") || lower.contains("chalu") || lower.contains("jalao")
            val turnOff = lower.contains("off") || lower.contains("band") || lower.contains("bujhao")
            val targetState = if (turnOn) true else if (turnOff) false else !isTorchOn
            return toggleFlashlight(targetState, userName)
        }

        // 7. Settings
        if (lower.contains("wifi") && (lower.contains("setting") || lower.contains("khol"))) {
            return launchSetting(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings khol rahi hoon $userName.")
        }
        if (lower.contains("bluetooth") && (lower.contains("setting") || lower.contains("khol"))) {
            return launchSetting(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings khol rahi hoon $userName.")
        }
        if (lower.contains("brightness") || (lower.contains("display") && lower.contains("setting"))) {
            return launchSetting(Settings.ACTION_DISPLAY_SETTINGS, "Display & Brightness settings open kar rahi hoon $userName.")
        }
        if (lower.contains("setting") && (lower.contains("khol") || lower.contains("open"))) {
            return launchSetting(Settings.ACTION_SETTINGS, "Android Settings open ho rahi hai $userName.")
        }

        // 8. Navigation (Home, Back, Recents)
        if (lower == "home" || lower.contains("home screen")) {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(homeIntent)
            return CommandResult.Executed("Home screen par bhej diya hai $userName.")
        }

        if (lower == "back" || lower.contains("peeche")) {
            val success = ArchanaAccessibilityService.performBack()
            return if (success) {
                CommandResult.Executed("Back kar diya $userName.")
            } else {
                CommandResult.Executed("Back karne ke liye Archana Accessibility Service enable kijiye.")
            }
        }

        if (lower.contains("recent app") || lower.contains("recent task")) {
            val success = ArchanaAccessibilityService.performRecents()
            return if (success) {
                CommandResult.Executed("Recent apps khol diye hain $userName.")
            } else {
                CommandResult.Executed("Recent apps dekhne ke liye Settings se Archana Accessibility service chalu karein.")
            }
        }

        // 9. Call command
        if (lower.startsWith("call") || lower.contains("ko call karo") || lower.contains("ko call lagao")) {
            return prepareCall(commandText, userName)
        }

        // 10. SMS command
        if (lower.startsWith("sms") || lower.startsWith("message") || lower.contains("ko sms")) {
            return prepareSms(commandText, userName)
        }

        return CommandResult.NotHandled
    }

    private fun openApp(packageName: String, appName: String, successSpeech: String): CommandResult {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            CommandResult.Executed(successSpeech)
        } else {
            // Open in Play Store or web
            try {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(marketIntent)
                CommandResult.Executed("$appName aapke phone par installed nahi hai. Play Store khol rahi hoon.")
            } catch (e: Exception) {
                CommandResult.Executed("$appName app install nahi mila.")
            }
        }
    }

    private fun launchSetting(action: String, message: String): CommandResult {
        return try {
            val intent = Intent(action).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            context.startActivity(intent)
            CommandResult.Executed(message)
        } catch (e: Exception) {
            CommandResult.Executed("Settings kholne mein asuvidha hui.")
        }
    }

    private fun toggleFlashlight(enable: Boolean, userName: String): CommandResult {
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, enable)
                isTorchOn = enable
                val stateText = if (enable) "chalu" else "band"
                CommandResult.Executed("Flashlight $stateText kar di hai $userName.")
            } else {
                CommandResult.Executed("Aapke phone mein flashlight uplabdh nahi hai.")
            }
        } catch (e: CameraAccessException) {
            CommandResult.Executed("Flashlight switch nahi ho saki.")
        } catch (e: Exception) {
            CommandResult.Executed("Flashlight control karne mein dikkat aayi.")
        }
    }

    private fun prepareCall(commandText: String, userName: String): CommandResult {
        // Extract number or name
        val numberRegex = Regex("""\d{3,15}""")
        val numberMatch = numberRegex.find(commandText)
        val target = numberMatch?.value ?: ""

        val intent = if (target.isNotBlank()) {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$target")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }
        return CommandResult.NeedsAction(
            message = if (target.isNotBlank()) "Call lagane ke liye dialer khol rahi hoon: $target" else "Call lagane ke liye Dialer khol rahi hoon $userName.",
            actionIntent = intent
        )
    }

    private fun prepareSms(commandText: String, userName: String): CommandResult {
        val numberRegex = Regex("""\d{3,15}""")
        val numberMatch = numberRegex.find(commandText)
        val target = numberMatch?.value ?: ""

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${if (target.isNotBlank()) target else ""}")
            putExtra("sms_body", "")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return CommandResult.NeedsAction(
            message = "SMS taiyaar kar diya hai $userName.",
            actionIntent = intent
        )
    }
}
