package com.example.whatsapp

import android.content.Context
import android.content.Intent
import android.net.Uri

class WhatsAppHandler(private val context: Context) {

    fun isWhatsAppInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("com.whatsapp", 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openWhatsApp(): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    fun prepareMessageIntent(phoneNumber: String?, messageText: String): Intent {
        val cleanNumber = phoneNumber?.replace(Regex("[^0-9+]"), "") ?: ""
        return if (cleanNumber.isNotBlank()) {
            val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=${Uri.encode(messageText)}"
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                `package` = "com.whatsapp"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, messageText)
                `package` = "com.whatsapp"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }
    }
}
