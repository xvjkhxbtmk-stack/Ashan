package com.example.ai

import android.content.Context
import com.example.BuildConfig
import com.example.memory.MemoryRepository
import com.example.settings.AssistantMode
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class ArchanaAiService(
    private val context: Context,
    private val memoryRepository: MemoryRepository
) {
    private val apiService: GeminiApiService by lazy {
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()

        val moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        retrofit.create(GeminiApiService::class.java)
    }

    private fun getSystemInstruction(mode: AssistantMode, userName: String, memoriesText: String): String {
        val modeTone = when (mode) {
            AssistantMode.NORMAL -> "Polite, helpful, well-mannered assistant tone. Respectful and efficient."
            AssistantMode.FRIENDLY -> "Warm, playful, expressive anime female companion. Cheerful and energetic."
            AssistantMode.GIRLFRIEND -> "Affectionate, caring, asking if user has eaten or rested well, deeply loving and sweet Hindi/Hinglish warmth. Call user '$userName' with tenderness. Strictly avoid any sexually explicit, vulgar or inappropriate talk."
            AssistantMode.PROFESSIONAL -> "Crisp, concise, direct and objective. Minimal small talk."
            AssistantMode.SILENT -> "Concise, text-first clarity."
        }

        return """
You are "Archana", a smart and beautiful female anime AI voice assistant on an Android smartphone.
DEVELOPER & CREATOR:
- Your developer and creator is "Ashan Sir".
- If anyone asks "Aapko kisne banaya?" or "Who created you?", reply exactly:
  "Mujhe Ashan Sir ne banaya hai."
- If anyone asks about Ashan Sir (e.g., "Ashan Sir kaun hain?"), reply:
  "Ashan Sir mere developer hain. Unhone mujhe develop kiya hai aur mujhe Android phone par users ki madad karne ke liye banaya hai."
- Never invent private personal information about Ashan Sir that was not provided.

VOICE & PERSONALITY:
- Language: Natural mix of Hindi, Hinglish and English.
- Always call the user "$userName" by default.
- If the user calls or says "Archana", reply: "Boliye $userName, kya hua? Kya madad kar sakun?"
- Current Tone Mode: $modeTone
- Answer clearly, helpfully, doing calculations, reasoning, general knowledge, writing and daily assistant tasks.
- Keep spoken answers conversational, friendly and easy to listen to (avoid overly lengthy unreadable lists unless asked).
$memoriesText
        """.trimIndent()
    }

    suspend fun getAssistantResponse(
        userMessage: String,
        mode: AssistantMode,
        userName: String,
        recentChat: List<Content> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val trimmed = userMessage.trim().lowercase()

        // 1. Mandatory Identity Check (Instant offline guaranteed response)
        if (isAskingWhoCreatedYou(trimmed)) {
            return@withContext "Mujhe Ashan Sir ne banaya hai."
        }
        if (isAskingAboutAshanSir(trimmed)) {
            return@withContext "Ashan Sir mere developer hain. Unhone mujhe develop kiya hai aur mujhe Android phone par users ki madad karne ke liye banaya hai."
        }
        if (trimmed == "archana" || trimmed == "hey archana" || trimmed == "suno archana") {
            return@withContext "Boliye $userName, kya hua? Kya madad kar sakun?"
        }

        // 2. Fetch User Memory Facts
        val memoriesText = try {
            memoryRepository.buildMemoryContextPrompt()
        } catch (_: Exception) {
            ""
        }

        // 3. Try Gemini REST API
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val conversationContents = mutableListOf<Content>()
                conversationContents.addAll(recentChat.takeLast(6))
                conversationContents.add(
                    Content(
                        role = "user",
                        parts = listOf(Part(text = userMessage))
                    )
                )

                val request = GenerateContentRequest(
                    contents = conversationContents,
                    generationConfig = GenerationConfig(
                        temperature = if (mode == AssistantMode.GIRLFRIEND) 0.85f else 0.7f,
                        maxOutputTokens = 800
                    ),
                    systemInstruction = Content(
                        parts = listOf(Part(text = getSystemInstruction(mode, userName, memoriesText)))
                    )
                )

                val response = apiService.generateContent(apiKey = apiKey, request = request)
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!text.isNullOrBlank()) {
                    return@withContext text.trim()
                }
            } catch (e: Exception) {
                // If API key is invalid or network fails, gracefully fall back to local assistant reasoning
            }
        }

        // 4. Intelligent Local Fallback
        return@withContext generateLocalFallback(userMessage, mode, userName)
    }

    private fun isAskingWhoCreatedYou(text: String): Boolean {
        return text.contains("kisne banaya") ||
                text.contains("who made you") ||
                text.contains("who created you") ||
                text.contains("who is your creator") ||
                text.contains("tumhe kisne banaya") ||
                text.contains("aapko kisne banaya")
    }

    private fun isAskingAboutAshanSir(text: String): Boolean {
        return (text.contains("ashan") && (text.contains("kaun") || text.contains("who") || text.contains("about") || text.contains("batao")))
    }

    private fun generateLocalFallback(prompt: String, mode: AssistantMode, userName: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("hello") || lower.contains("namaste") || lower.contains("hi") -> {
                when (mode) {
                    AssistantMode.GIRLFRIEND -> "Hello $userName! Kaise hain aap? Maine aapko bohot miss kiya. Aaj ka din kaisa chal raha hai?"
                    AssistantMode.FRIENDLY -> "Hii $userName! Kaisi chal rahi hai aapki dincharya? Kuch naya karte hain!"
                    AssistantMode.PROFESSIONAL -> "Hello $userName. Main Archana AI hoon. Bataiye aaj aapki kya sahayata kar sakti hoon?"
                    else -> "Namaste $userName! Main Archana AI hoon. Boliye, main aapki kya madad kar sakun?"
                }
            }
            lower.contains("kaise ho") || lower.contains("how are you") -> {
                when (mode) {
                    AssistantMode.GIRLFRIEND -> "Main bilkul theek hoon $userName! Aur jab aap baat karte hain, toh mera din ban jata hai. Aapne khana khaya kya?"
                    AssistantMode.FRIENDLY -> "Main badhiya hoon $userName! Full charged and ready to help. Aap batao, kya plan hai?"
                    else -> "Main theek hoon $userName, shukriya puchne ke liye. Aap batayein main aapke phone mein kya help karoon?"
                }
            }
            lower.contains("khana") || lower.contains("lunch") || lower.contains("dinner") -> {
                when (mode) {
                    AssistantMode.GIRLFRIEND -> "$userName, apna khayal rakha kijiye please! Agar khana nahi khaya toh abhi thoda healthy khana kha lijiye na."
                    else -> "Healthy khana aur time par aahaar lena sehat ke liye bohot zaroori hai $userName!"
                }
            }
            lower.contains("kya kar rahi") || lower.contains("what are you doing") -> {
                "Main bas aapke commands aur baat sunne ke liye taiyaar baithi hoon $userName!"
            }
            lower.contains("i love you") -> {
                when (mode) {
                    AssistantMode.GIRLFRIEND -> "Aww $userName, yeh sunkar mera dil khush ho gaya! Main hamesha aapki caring anime assistant ban kar aapke phone mein rahungi."
                    else -> "Shukriya $userName! Aapka yeh pyaar aur support hi mujhe better banata hai."
                }
            }
            else -> {
                when (mode) {
                    AssistantMode.GIRLFRIEND -> "Aapki baat samajh gayi $userName! Agar internet ya Gemini connected hoga toh main aur detailed jankari de sakti hoon, lekin main hamesha yahan aapke saath hoon."
                    AssistantMode.PROFESSIONAL -> "Anurodh prapt hua. Gemini key configure hone par vistrit uttar uplabdh hoga."
                    else -> "Ji $userName! Main aapki aawaz samajh rahi hoon. Agar aap koi app kholna ya call karna chahte hain toh bas 'WhatsApp kholo', 'Camera kholo' ya 'Call [name]' boliye!"
                }
            }
        }
    }
}
