package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.ArchanaAiService
import com.example.ai.Content
import com.example.ai.Part
import com.example.character.CharacterExpression
import com.example.memory.ArchanaDatabase
import com.example.memory.ConversationEntity
import com.example.memory.MemoryEntity
import com.example.memory.MemoryRepository
import com.example.overlay.FloatingOverlayService
import com.example.permissions.PermissionManager
import com.example.phone.CommandResult
import com.example.phone.PhoneActionHandler
import com.example.settings.ArchanaPreferences
import com.example.settings.AssistantMode
import com.example.voice.ArchanaTtsManager
import com.example.voice.ArchanaVoiceRecognizer
import com.example.whatsapp.WhatsAppHandler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ActiveSheet {
    SETTINGS,
    MEMORY,
    PERMISSIONS,
    WHATSAPP_REVIEW
}

data class ArchanaUiState(
    val assistantMode: AssistantMode = AssistantMode.FRIENDLY,
    val characterExpression: CharacterExpression = CharacterExpression.IDLE,
    val statusText: String = "Archana AI Ready",
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val listeningRms: Float = 0f,
    val speakingAmplitude: Float = 0f,
    val isWakeWordEnabled: Boolean = true,
    val isFloatingOverlayEnabled: Boolean = false,
    val isContinuousListening: Boolean = false,
    val ttsPitch: Float = 1.25f,
    val ttsSpeed: Float = 1.0f,
    val userName: String = "Sir",
    val activeSheet: ActiveSheet? = null,
    val pendingWhatsAppMessage: Pair<String?, String>? = null,
    val pendingActionIntent: Intent? = null
)

class ArchanaViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val preferences = ArchanaPreferences(context)
    private val database = ArchanaDatabase.getInstance(context)
    private val memoryRepo = MemoryRepository(database.archanaDao())
    private val aiService = ArchanaAiService(context, memoryRepo)
    private val phoneHandler = PhoneActionHandler(context)
    private val whatsAppHandler = WhatsAppHandler(context)

    val memories: StateFlow<List<MemoryEntity>> = memoryRepo.memories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversations: StateFlow<List<ConversationEntity>> = memoryRepo.conversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(
        ArchanaUiState(
            assistantMode = preferences.mode,
            isWakeWordEnabled = preferences.isWakeWordEnabled,
            isFloatingOverlayEnabled = preferences.isFloatingOverlayEnabled,
            isContinuousListening = preferences.isContinuousListeningEnabled,
            ttsPitch = preferences.ttsPitch,
            ttsSpeed = preferences.ttsSpeed,
            userName = preferences.userName
        )
    )
    val uiState: StateFlow<ArchanaUiState> = _uiState.asStateFlow()

    private val ttsManager = ArchanaTtsManager(context).apply {
        pitch = preferences.ttsPitch
        speed = preferences.ttsSpeed
        onSpeechComplete = {
            _uiState.value = _uiState.value.copy(
                isSpeaking = false,
                characterExpression = CharacterExpression.IDLE,
                statusText = "Boliye ${_uiState.value.userName}"
            )
            if (_uiState.value.isContinuousListening && PermissionManager.hasRecordAudioPermission(context)) {
                startListening()
            }
        }
    }

    private val voiceRecognizer = ArchanaVoiceRecognizer(
        context = context,
        onResult = { text ->
            processUserInput(text)
        },
        onPartial = { partial ->
            _uiState.value = _uiState.value.copy(
                statusText = "\"$partial\""
            )
        },
        onWakeWordDetected = {
            onWakeWordTriggered()
        }
    )

    init {
        // Collect TTS amplitude
        viewModelScope.launch {
            ttsManager.isSpeaking.collect { speaking ->
                _uiState.value = _uiState.value.copy(isSpeaking = speaking)
                if (speaking) {
                    _uiState.value = _uiState.value.copy(
                        characterExpression = if (_uiState.value.assistantMode == AssistantMode.GIRLFRIEND)
                            CharacterExpression.AFFECTIONATE else CharacterExpression.SPEAKING,
                        statusText = "Speaking..."
                    )
                }
            }
        }
        viewModelScope.launch {
            ttsManager.speakingAmplitude.collect { amp ->
                _uiState.value = _uiState.value.copy(speakingAmplitude = amp)
            }
        }

        // Collect Voice Recognizer
        viewModelScope.launch {
            voiceRecognizer.isListening.collect { listening ->
                _uiState.value = _uiState.value.copy(
                    isListening = listening,
                    characterExpression = if (listening) CharacterExpression.LISTENING else _uiState.value.characterExpression,
                    statusText = if (listening) "Listening..." else _uiState.value.statusText
                )
            }
        }
        viewModelScope.launch {
            voiceRecognizer.rmsVolume.collect { rms ->
                _uiState.value = _uiState.value.copy(listeningRms = rms)
            }
        }

        voiceRecognizer.isWakeWordMode = preferences.isWakeWordEnabled
    }

    fun toggleListening() {
        if (!PermissionManager.hasRecordAudioPermission(context)) {
            _uiState.value = _uiState.value.copy(activeSheet = ActiveSheet.PERMISSIONS)
            return
        }

        if (_uiState.value.isListening) {
            voiceRecognizer.stopListening()
            _uiState.value = _uiState.value.copy(
                isListening = false,
                statusText = "Archana AI Ready",
                characterExpression = CharacterExpression.IDLE
            )
        } else {
            ttsManager.stop()
            startListening()
        }
    }

    private fun startListening() {
        _uiState.value = _uiState.value.copy(
            isListening = true,
            statusText = "Listening...",
            characterExpression = CharacterExpression.LISTENING
        )
        voiceRecognizer.startListening()
    }

    fun onWakeWordTriggered() {
        ttsManager.stop()
        voiceRecognizer.stopListening()
        val response = "Boliye ${_uiState.value.userName}, kya hua? Kya madad kar sakun?"
        speakResponse(response, updateHistory = true, userPrompt = "Archana")
    }

    fun processUserInput(input: String) {
        if (input.isBlank()) return
        val trimmed = input.trim()

        viewModelScope.launch {
            // Save User Message
            memoryRepo.recordMessage("user", trimmed, _uiState.value.assistantMode.name)

            // 1. Check Phone Action Handler
            val actionResult = phoneHandler.tryHandleCommand(trimmed, _uiState.value.userName)
            when (actionResult) {
                is CommandResult.Executed -> {
                    speakResponse(actionResult.speechResponse, updateHistory = true, userPrompt = trimmed)
                    return@launch
                }
                is CommandResult.NeedsAction -> {
                    _uiState.value = _uiState.value.copy(pendingActionIntent = actionResult.actionIntent)
                    speakResponse(actionResult.message, updateHistory = true, userPrompt = trimmed)
                    return@launch
                }
                is CommandResult.NeedsPermission -> {
                    _uiState.value = _uiState.value.copy(activeSheet = ActiveSheet.PERMISSIONS)
                    speakResponse(actionResult.reason, updateHistory = true, userPrompt = trimmed)
                    return@launch
                }
                CommandResult.NotHandled -> {
                    // Proceed to Gemini AI
                }
            }

            // 2. Query Archana AI / Gemini
            _uiState.value = _uiState.value.copy(
                statusText = "Thinking...",
                characterExpression = CharacterExpression.THINKING
            )

            val recentChat = conversations.value.takeLast(6).map { entity ->
                Content(
                    role = if (entity.sender == "user") "user" else "model",
                    parts = listOf(Part(text = entity.message))
                )
            }

            val response = aiService.getAssistantResponse(
                userMessage = trimmed,
                mode = _uiState.value.assistantMode,
                userName = _uiState.value.userName,
                recentChat = recentChat
            )

            speakResponse(response, updateHistory = true, userPrompt = trimmed)
        }
    }

    fun speakResponse(response: String, updateHistory: Boolean = true, userPrompt: String = "") {
        viewModelScope.launch {
            if (updateHistory) {
                memoryRepo.recordMessage("archana", response, _uiState.value.assistantMode.name)
            }

            _uiState.value = _uiState.value.copy(
                statusText = "Speaking...",
                characterExpression = if (_uiState.value.assistantMode == AssistantMode.GIRLFRIEND)
                    CharacterExpression.AFFECTIONATE else CharacterExpression.SPEAKING
            )

            if (_uiState.value.assistantMode != AssistantMode.SILENT) {
                ttsManager.speak(response)
            } else {
                _uiState.value = _uiState.value.copy(
                    characterExpression = CharacterExpression.IDLE,
                    statusText = "Archana AI Ready"
                )
            }
        }
    }

    fun onCharacterTapped() {
        ttsManager.stop()
        val greetings = when (_uiState.value.assistantMode) {
            AssistantMode.GIRLFRIEND -> listOf(
                "Haan ${_uiState.value.userName}! Main hamesha aapke paas hoon.",
                "Aapki Archana haazir hai ${_uiState.value.userName}! Kuch help chahiye?",
                "Muskurate rahiye ${_uiState.value.userName}, aap haste hue bohot acche lagte hain!"
            )
            AssistantMode.FRIENDLY -> listOf(
                "Boliye ${_uiState.value.userName}! Kya plan hai?",
                "Yay! Archana active hai. Kuch poochiye!",
                "Full energy mein hoon ${_uiState.value.userName}!"
            )
            AssistantMode.PROFESSIONAL -> listOf(
                "Archana AI active. Awaiting your command, ${_uiState.value.userName}.",
                "How may I assist you today, ${_uiState.value.userName}?"
            )
            else -> listOf(
                "Boliye ${_uiState.value.userName}, main aapki kya madad kar sakun?",
                "Ji ${_uiState.value.userName}, main sun rahi hoon."
            )
        }
        val randomGreeting = greetings.random()
        speakResponse(randomGreeting, updateHistory = false)
    }

    fun setAssistantMode(mode: AssistantMode) {
        preferences.mode = mode
        _uiState.value = _uiState.value.copy(assistantMode = mode)
        val feedback = when (mode) {
            AssistantMode.GIRLFRIEND -> "Girlfriend mode activate ho gaya hai ${_uiState.value.userName}! Main aapka pura khayal rakhungi."
            AssistantMode.FRIENDLY -> "Friendly mode on! Chaliye masti karte hain."
            AssistantMode.PROFESSIONAL -> "Professional mode enabled, ${_uiState.value.userName}."
            AssistantMode.SILENT -> "Silent mode on."
            AssistantMode.NORMAL -> "Normal mode enabled ${_uiState.value.userName}."
        }
        speakResponse(feedback, updateHistory = false)
    }

    fun setTtsPitch(pitch: Float) {
        preferences.ttsPitch = pitch
        ttsManager.pitch = pitch
        _uiState.value = _uiState.value.copy(ttsPitch = pitch)
    }

    fun setTtsSpeed(speed: Float) {
        preferences.ttsSpeed = speed
        ttsManager.speed = speed
        _uiState.value = _uiState.value.copy(ttsSpeed = speed)
    }

    fun setUserName(name: String) {
        val trimmed = name.trim().ifBlank { "Sir" }
        preferences.userName = trimmed
        _uiState.value = _uiState.value.copy(userName = trimmed)
    }

    fun toggleWakeWord(enabled: Boolean) {
        preferences.isWakeWordEnabled = enabled
        voiceRecognizer.isWakeWordMode = enabled
        _uiState.value = _uiState.value.copy(isWakeWordEnabled = enabled)
    }

    fun toggleContinuousListening(enabled: Boolean) {
        preferences.isContinuousListeningEnabled = enabled
        _uiState.value = _uiState.value.copy(isContinuousListening = enabled)
    }

    fun toggleFloatingOverlay(enabled: Boolean) {
        if (enabled && !PermissionManager.hasOverlayPermission(context)) {
            _uiState.value = _uiState.value.copy(activeSheet = ActiveSheet.PERMISSIONS)
            return
        }

        preferences.isFloatingOverlayEnabled = enabled
        _uiState.value = _uiState.value.copy(isFloatingOverlayEnabled = enabled)
        if (enabled) {
            FloatingOverlayService.start(context)
        } else {
            FloatingOverlayService.stop(context)
        }
    }

    fun showSheet(sheet: ActiveSheet?) {
        _uiState.value = _uiState.value.copy(activeSheet = sheet)
    }

    fun saveMemory(key: String, value: String, category: String = "general") {
        viewModelScope.launch {
            memoryRepo.saveMemory(key, value, category)
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            memoryRepo.deleteMemory(id)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            memoryRepo.clearAllMemories()
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            memoryRepo.clearAllConversations()
        }
    }

    fun openWhatsAppReview(phoneNumber: String?, message: String) {
        _uiState.value = _uiState.value.copy(
            pendingWhatsAppMessage = Pair(phoneNumber, message),
            activeSheet = ActiveSheet.WHATSAPP_REVIEW
        )
    }

    fun confirmSendWhatsApp(phoneNumber: String?, message: String) {
        val intent = whatsAppHandler.prepareMessageIntent(phoneNumber, message)
        context.startActivity(intent)
        _uiState.value = _uiState.value.copy(
            activeSheet = null,
            pendingWhatsAppMessage = null
        )
    }

    fun clearPendingActionIntent() {
        _uiState.value = _uiState.value.copy(pendingActionIntent = null)
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        voiceRecognizer.destroy()
    }
}
