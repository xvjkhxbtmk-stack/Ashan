package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ArchanaDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color(0xFF00222B),
    primaryContainer = Color(0xFF004D5A),
    onPrimaryContainer = Color(0xFF9CF0FF),

    secondary = ElectricViolet,
    onSecondary = Color(0xFF2E0559),
    secondaryContainer = Color(0xFF4C1D82),
    onSecondaryContainer = Color(0xFFEADBFF),

    tertiary = AnimePink,
    onTertiary = Color(0xFF4A0021),
    tertiaryContainer = Color(0xFF7A043B),
    onTertiaryContainer = Color(0xFFFFD8E4),

    background = CyberBackground,
    onBackground = CyberTextPrimary,
    surface = CyberSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberSurfaceBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep dark futuristic look consistent
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = ArchanaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
