package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.character.ArchanaCharacterView
import com.example.memory.ConversationEntity
import com.example.settings.AssistantMode
import com.example.ui.theme.AnimePink
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ElectricViolet
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    viewModel: ArchanaViewModel,
    onRequestRuntimePermissions: () -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val conversations by viewModel.conversations.collectAsState()
    val memories by viewModel.memories.collectAsState()

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Handle any pending action intents from voice commands
    LaunchedEffect(uiState.pendingActionIntent) {
        uiState.pendingActionIntent?.let { intent ->
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not launch activity", Toast.LENGTH_SHORT).show()
            }
            viewModel.clearPendingActionIntent()
        }
    }

    // Auto-scroll to bottom of conversations
    LaunchedEffect(conversations.size) {
        if (conversations.isNotEmpty()) {
            listState.animateScrollToItem(conversations.size - 1)
        }
    }

    Scaffold(
        containerColor = CyberBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_screen")
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Bar
            TopBar(
                currentMode = uiState.assistantMode,
                userName = uiState.userName,
                onModeClick = { viewModel.showSheet(ActiveSheet.SETTINGS) },
                onMemoryClick = { viewModel.showSheet(ActiveSheet.MEMORY) },
                onSettingsClick = { viewModel.showSheet(ActiveSheet.SETTINGS) },
                onPermissionsClick = { viewModel.showSheet(ActiveSheet.PERMISSIONS) }
            )

            // 2. Anime Character Hero Section (Interactive Centerpiece)
            ArchanaCharacterView(
                modifier = Modifier
                    .padding(top = 4.dp, bottom = 4.dp),
                expression = uiState.characterExpression,
                assistantMode = uiState.assistantMode,
                isSpeaking = uiState.isSpeaking,
                speakingAmplitude = uiState.speakingAmplitude,
                isListening = uiState.isListening,
                listeningRms = uiState.listeningRms,
                onCharacterTap = { viewModel.onCharacterTapped() }
            )

            // 3. Quick Action Row
            QuickActionsRow(
                onAction = { cmd -> viewModel.processUserInput(cmd) },
                onWhatsAppDirect = { viewModel.openWhatsAppReview(null, "") }
            )

            // 4. Conversation History (Scrollable chat)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp)
            ) {
                if (conversations.isEmpty()) {
                    EmptyConversationState(
                        userName = uiState.userName,
                        onSamplePromptClick = { prompt ->
                            viewModel.processUserInput(prompt)
                        }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(conversations, key = { it.id }) { item ->
                            ConversationBubble(
                                item = item,
                                onCopy = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Archana Chat", item.message))
                                    Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                                },
                                onReplaySpeech = {
                                    viewModel.speakResponse(item.message, updateHistory = false)
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 5. Bottom Voice & Text Input Bar
            BottomInputBar(
                inputText = inputText,
                onInputTextChange = { inputText = it },
                onSend = {
                    if (inputText.isNotBlank()) {
                        val text = inputText
                        inputText = ""
                        viewModel.processUserInput(text)
                    }
                },
                isListening = uiState.isListening,
                isSpeaking = uiState.isSpeaking,
                onMicToggle = { viewModel.toggleListening() }
            )
        }
    }

    // Modal Sheets and Dialogs
    when (uiState.activeSheet) {
        ActiveSheet.SETTINGS -> {
            SettingsSheet(
                currentMode = uiState.assistantMode,
                isWakeWordEnabled = uiState.isWakeWordEnabled,
                isFloatingOverlayEnabled = uiState.isFloatingOverlayEnabled,
                isContinuousListening = uiState.isContinuousListening,
                ttsPitch = uiState.ttsPitch,
                ttsSpeed = uiState.ttsSpeed,
                userName = uiState.userName,
                onModeSelected = { viewModel.setAssistantMode(it) },
                onToggleWakeWord = { viewModel.toggleWakeWord(it) },
                onToggleFloatingOverlay = { viewModel.toggleFloatingOverlay(it) },
                onToggleContinuousListening = { viewModel.toggleContinuousListening(it) },
                onSetPitch = { viewModel.setTtsPitch(it) },
                onSetSpeed = { viewModel.setTtsSpeed(it) },
                onSetUserName = { viewModel.setUserName(it) },
                onDismiss = { viewModel.showSheet(null) }
            )
        }
        ActiveSheet.MEMORY -> {
            MemorySheet(
                memories = memories,
                onSaveMemory = { k, v, c -> viewModel.saveMemory(k, v, c) },
                onDeleteMemory = { id -> viewModel.deleteMemory(id) },
                onClearAll = { viewModel.clearAllMemories() },
                onDismiss = { viewModel.showSheet(null) }
            )
        }
        ActiveSheet.PERMISSIONS -> {
            PermissionsSheet(
                onRequestRuntimePermissions = {
                    viewModel.showSheet(null)
                    onRequestRuntimePermissions()
                },
                onDismiss = { viewModel.showSheet(null) }
            )
        }
        ActiveSheet.WHATSAPP_REVIEW -> {
            val pending = uiState.pendingWhatsAppMessage
            WhatsAppReviewDialog(
                initialPhone = pending?.first,
                initialMessage = pending?.second.orEmpty(),
                onConfirmSend = { phone, msg ->
                    viewModel.confirmSendWhatsApp(phone, msg)
                },
                onDismiss = { viewModel.showSheet(null) }
            )
        }
        null -> {}
    }
}

@Composable
private fun TopBar(
    currentMode: AssistantMode,
    userName: String,
    onModeClick: () -> Unit,
    onMemoryClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onPermissionsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title & Mode Chip
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { onModeClick() }
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(CyberCyan, ElectricViolet))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Archana AI",
                    color = CyberTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = currentMode.title,
                    color = if (currentMode == AssistantMode.GIRLFRIEND) AnimePink else CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Action Buttons (Memory, Permissions, Settings)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onMemoryClick,
                modifier = Modifier.testTag("memory_icon_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Bookmark,
                    contentDescription = "Memories",
                    tint = CyberCyan
                )
            }
            IconButton(
                onClick = onPermissionsClick,
                modifier = Modifier.testTag("permissions_icon_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Permissions",
                    tint = ElectricViolet
                )
            }
            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier.testTag("settings_icon_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = CyberTextSecondary
                )
            }
        }
    }
}

@Composable
private fun QuickActionsRow(
    onAction: (String) -> Unit,
    onWhatsAppDirect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QuickChip("WhatsApp", Icons.AutoMirrored.Filled.Send, CyberCyan) { onAction("WhatsApp kholo") }
        QuickChip("Instagram", Icons.Default.CameraAlt, ElectricViolet) { onAction("Instagram kholo") }
        QuickChip("YouTube", Icons.AutoMirrored.Filled.VolumeUp, AnimePink) { onAction("YouTube kholo") }
        QuickChip("Camera", Icons.Default.CameraAlt, CyberCyan) { onAction("Camera kholo") }
        QuickChip("Flashlight", Icons.Default.FlashOn, Color(0xFFFFD700)) { onAction("Flashlight on") }
        QuickChip("Settings", Icons.Default.Settings, CyberTextSecondary) { onAction("Settings kholo") }
        QuickChip("Wi-Fi", Icons.Default.Wifi, CyberCyan) { onAction("Wi-Fi settings kholo") }
        QuickChip("Call", Icons.Default.Phone, Color(0xFF00E676)) { onAction("Call lagao") }
    }
}

@Composable
private fun QuickChip(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    SuggestionChip(
        onClick = onClick,
        label = { Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
        icon = { Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp)) },
        colors = SuggestionChipDefaults.suggestionChipColors(containerColor = CyberSurfaceVariant),
        border = SuggestionChipDefaults.suggestionChipBorder(
            enabled = true,
            borderColor = color.copy(alpha = 0.4f),
            borderWidth = 1.dp
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.testTag("chip_$label")
    )
}

@Composable
private fun EmptyConversationState(
    userName: String,
    onSamplePromptClick: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Namaste $userName!",
            color = CyberCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Say \"Archana\" or tap the microphone to start talking.",
            color = CyberTextSecondary,
            fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Sample Prompts
        val prompts = listOf(
            "Aapko kisne banaya?",
            "Ashan Sir kaun hain?",
            "WhatsApp kholo",
            "Flashlight on karo",
            "Aaj ka din kaisa hai?"
        )
        prompts.forEach { prompt ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .padding(vertical = 3.dp)
                    .clickable { onSamplePromptClick(prompt) }
                    .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(12.dp))
            ) {
                Text(
                    text = "\"$prompt\"",
                    color = CyberTextPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun ConversationBubble(
    item: ConversationEntity,
    onCopy: () -> Unit,
    onReplaySpeech: () -> Unit
) {
    val isUser = item.sender == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) Color(0xFF271545) else CyberSurfaceVariant
            ),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier
                .widthIn(max = 300.dp)
                .border(
                    width = 1.dp,
                    color = if (isUser) ElectricViolet.copy(alpha = 0.5f) else CyberCyan.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) "You" else "Archana",
                        color = if (isUser) ElectricViolet else CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row {
                        if (!isUser) {
                            IconButton(
                                onClick = onReplaySpeech,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Speak",
                                    tint = CyberCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = onCopy,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = CyberTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = item.message,
                    color = CyberTextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun BottomInputBar(
    inputText: String,
    onInputTextChange: (String) -> Unit,
    onSend: () -> Unit,
    isListening: Boolean,
    isSpeaking: Boolean,
    onMicToggle: () -> Unit
) {
    val micTransition = rememberInfiniteTransition(label = "mic_pulse")
    val micPulseScale by micTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val micColor by animateColorAsState(
        targetValue = when {
            isListening -> CyberCyan
            isSpeaking -> AnimePink
            else -> ElectricViolet
        },
        label = "mic_color"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Text Input Field
        OutlinedTextField(
            value = inputText,
            onValueChange = onInputTextChange,
            placeholder = { Text("Message or command Archana...", color = CyberTextSecondary, fontSize = 13.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CyberSurfaceVariant,
                unfocusedContainerColor = CyberSurfaceVariant,
                focusedBorderColor = CyberCyan,
                unfocusedBorderColor = CyberSurfaceBorder,
                focusedTextColor = CyberTextPrimary,
                unfocusedTextColor = CyberTextPrimary
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .weight(1f)
                .testTag("chat_text_input")
        )

        Spacer(modifier = Modifier.width(8.dp))

        // Send or Mic Action
        if (inputText.isNotBlank()) {
            IconButton(
                onClick = onSend,
                modifier = Modifier
                    .size(48.dp)
                    .background(CyberCyan, CircleShape)
                    .testTag("send_message_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = Color(0xFF00222B),
                    modifier = Modifier.size(20.dp)
                )
            }
        } else {
            // Large Glowing Microphone Button
            FloatingActionButton(
                onClick = onMicToggle,
                containerColor = micColor,
                contentColor = Color.Black,
                shape = CircleShape,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .size(54.dp)
                    .scale(micPulseScale)
                    .shadow(
                        elevation = if (isListening) 16.dp else 6.dp,
                        shape = CircleShape,
                        spotColor = micColor,
                        ambientColor = micColor
                    )
                    .testTag("voice_mic_button")
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                    contentDescription = if (isListening) "Stop Listening" else "Start Voice Command",
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
