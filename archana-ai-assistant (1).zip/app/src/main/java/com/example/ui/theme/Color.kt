package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Cyber Anime Palette
val CyberCyan = Color(0xFF00E5FF)
val ElectricViolet = Color(0xFFB388FF)
val AnimePink = Color(0xFFFF4081)
val CyberBackground = Color(0xFF0A0514)
val CyberSurface = Color(0xFF140C24)
val CyberSurfaceVariant = Color(0xFF22143B)
val CyberSurfaceBorder = Color(0xFF3B2563)

val CyberTextPrimary = Color(0xFFF3EFFF)
val CyberTextSecondary = Color(0xFFB3A8CC)
val CyberTextAccent = Color(0xFF00E5FF)

val StatusListeningColor = Color(0xFF00E5FF)
val StatusSpeakingColor = Color(0xFFE040FB)
val StatusThinkingColor = Color(0xFFFFD700)
val StatusIdleColor = Color(0xFF9E9E9E)
