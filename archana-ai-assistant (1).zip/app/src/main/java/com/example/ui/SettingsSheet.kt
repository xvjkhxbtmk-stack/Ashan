package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.settings.AssistantMode
import com.example.ui.theme.AnimePink
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ElectricViolet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    currentMode: AssistantMode,
    isWakeWordEnabled: Boolean,
    isFloatingOverlayEnabled: Boolean,
    isContinuousListening: Boolean,
    ttsPitch: Float,
    ttsSpeed: Float,
    userName: String,
    onModeSelected: (AssistantMode) -> Unit,
    onToggleWakeWord: (Boolean) -> Unit,
    onToggleFloatingOverlay: (Boolean) -> Unit,
    onToggleContinuousListening: (Boolean) -> Unit,
    onSetPitch: (Float) -> Unit,
    onSetSpeed: (Float) -> Unit,
    onSetUserName: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var nameInput by remember { mutableStateOf(userName) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CyberSurface,
        dragHandle = null,
        modifier = Modifier.testTag("settings_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = CyberCyan
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Archana AI Settings",
                        color = CyberTextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = CyberTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // User Name
            Text("User Calling Name", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("How Archana addresses you in conversation", color = CyberTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = nameInput,
                onValueChange = {
                    nameInput = it
                    onSetUserName(it)
                },
                singleLine = true,
                placeholder = { Text("Sir") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CyberSurfaceBorder,
                    focusedTextColor = CyberTextPrimary,
                    unfocusedTextColor = CyberTextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("user_name_input")
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Modes Section
            Text("Personality Mode", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Change Archana's demeanor and conversation style", color = CyberTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(10.dp))

            AssistantMode.entries.forEach { mode ->
                val isSelected = mode == currentMode
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) CyberSurfaceVariant else Color(0xFF0F081C)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) (if (mode == AssistantMode.GIRLFRIEND) AnimePink else CyberCyan) else CyberSurfaceBorder,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { onModeSelected(mode) }
                        .testTag("mode_${mode.name}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    if (mode == AssistantMode.GIRLFRIEND) AnimePink.copy(alpha = 0.2f) else CyberCyan.copy(alpha = 0.2f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (mode == AssistantMode.GIRLFRIEND) Icons.Default.Favorite else Icons.Default.Person,
                                contentDescription = null,
                                tint = if (mode == AssistantMode.GIRLFRIEND) AnimePink else CyberCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mode.title,
                                color = if (isSelected) CyberTextPrimary else CyberTextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = mode.description,
                                color = CyberTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Voice Synthesizer Controls
            Text("Voice Synthesis (TTS)", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Text("Anime Voice Pitch: ${String.format("%.2f", ttsPitch)}x", color = CyberTextPrimary, fontSize = 13.sp)
            Slider(
                value = ttsPitch,
                onValueChange = onSetPitch,
                valueRange = 0.8f..1.8f,
                colors = SliderDefaults.colors(
                    thumbColor = CyberCyan,
                    activeTrackColor = CyberCyan,
                    inactiveTrackColor = CyberSurfaceBorder
                ),
                modifier = Modifier.testTag("pitch_slider")
            )

            Text("Speech Rate: ${String.format("%.2f", ttsSpeed)}x", color = CyberTextPrimary, fontSize = 13.sp)
            Slider(
                value = ttsSpeed,
                onValueChange = onSetSpeed,
                valueRange = 0.7f..1.5f,
                colors = SliderDefaults.colors(
                    thumbColor = ElectricViolet,
                    activeTrackColor = ElectricViolet,
                    inactiveTrackColor = CyberSurfaceBorder
                ),
                modifier = Modifier.testTag("speed_slider")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Feature Toggles
            Text("Voice & Overlay Toggles", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            // Wake Word Switch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Wake Word ('Archana')", color = CyberTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Respond automatically when you say 'Archana'", color = CyberTextSecondary, fontSize = 12.sp)
                }
                Switch(
                    checked = isWakeWordEnabled,
                    onCheckedChange = onToggleWakeWord,
                    colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("wake_word_switch")
                )
            }

            // Floating Overlay Switch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Floating Character Overlay", color = CyberTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Show Archana's anime avatar floating above other apps", color = CyberTextSecondary, fontSize = 12.sp)
                }
                Switch(
                    checked = isFloatingOverlayEnabled,
                    onCheckedChange = onToggleFloatingOverlay,
                    colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("floating_overlay_switch")
                )
            }

            // Continuous Listening Switch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Continuous Voice Conversation", color = CyberTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Automatically listen for reply after Archana finishes speaking", color = CyberTextSecondary, fontSize = 12.sp)
                }
                Switch(
                    checked = isContinuousListening,
                    onCheckedChange = onToggleContinuousListening,
                    colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("continuous_voice_switch")
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Developer Info Card
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = ElectricViolet)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("About Archana & Developer", color = ElectricViolet, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Creator: Ashan Sir\n" +
                                "• Archana Identity: \"Mujhe Ashan Sir ne banaya hai.\"\n" +
                                "• Ashan Sir mere developer hain. Unhone mujhe develop kiya hai aur mujhe Android phone par users ki madad karne ke liye banaya hai.\n" +
                                "• Privacy: No secret recordings, contacts and microphone are only accessed upon direct voice commands.",
                        color = CyberTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
