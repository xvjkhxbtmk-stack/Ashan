package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.permissions.PermissionManager
import com.example.ui.ArchanaViewModel
import com.example.ui.MainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: ArchanaViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val micGranted = results[android.Manifest.permission.RECORD_AUDIO] == true
        if (micGranted) {
            Toast.makeText(this, "Microphone enabled! You can now speak to Archana.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainScreen(
                    viewModel = viewModel,
                    onRequestRuntimePermissions = {
                        permissionLauncher.launch(
                            PermissionManager.getRequiredRuntimePermissions().toTypedArray()
                        )
                    }
                )
            }
        }
    }
}
