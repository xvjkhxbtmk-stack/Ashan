# Archana AI - Android Voice Assistant

**Archana AI** is a professional anime AI voice assistant application developed for Android. It features continuous voice conversations in Hindi, Hinglish, and English, smart phone automation, an interactive animated anime character, local Room database memory, and Google Gemini API integration.

---

## 🌟 Identity & Personality
- **Assistant Name**: Archana
- **Developer & Creator**: Ashan Sir
- **Creator Response**:
  - *"Aapko kisne banaya?"* -> *"Mujhe Ashan Sir ne banaya hai."*
  - *"Ashan Sir kaun hain?"* -> *"Ashan Sir mere developer hain. Unhone mujhe develop kiya hai aur mujhe Android phone par users ki madad karne ke liye banaya hai."*
- **Personality Modes**:
  - **Normal**: Polite, respectful, and balanced AI assistant.
  - **Friendly**: Cheerful, expressive anime companion.
  - **Girlfriend-style**: Affectionate, caring, asking if you ate, attentive and sweet Hindi/Hinglish warmth (strictly safe).
  - **Professional**: Direct, concise, formal.
  - **Silent**: Text-only responses without TTS audio.
- **Wake Word**: Calling *"Archana"* prompts *"Boliye Sir, kya hua? Kya madad kar sakun?"*

---

## 🚀 Key Features

1. **Interactive Anime Character View**:
   - Dynamic lip-sync responding to audio speech amplitude.
   - Natural blinking and subtle breathing animations.
   - Holographic aura ring with rotating cyber nodes and audio waveform ripples.
   - Interactive tap reactions.

2. **Floating Character Overlay**:
   - Movable floating bubble that stays on top of other apps (`SYSTEM_ALERT_WINDOW`).
   - Tap to immediately open Archana voice assistant.

3. **Android Phone Control & Automation**:
   - **Apps**: WhatsApp, Instagram, YouTube, Chrome, Camera.
   - **Device Toggles**: Flashlight / Torch, Wi-Fi Settings, Bluetooth Settings, System Settings.
   - **Phone Calls & SMS**: Direct voice dialing and SMS drafting with user confirmation.
   - **System Navigation**: Accessibility service integration for Home, Back, and Recent Apps.
   - **WhatsApp Review Dialog**: Review destination number and message text before sending.

4. **Offline Resilience & Memory**:
   - Local Room Database (`memories` and `conversations`).
   - Intelligent local fallback for persona questions and device controls even without internet.

---

## 🛠️ Requirements & Setup

- **Android Studio**: Ladybug (2024.2.1) or newer recommended
- **JDK**: Java 17 or Java 21
- **Android SDK**: `minSdk = 26` (Android 8.0), `targetSdk = 36`, `compileSdk = 36`
- **Kotlin**: 2.0.21

### Gemini API Key Configuration
Create a `.env` file in the project root (copied from `.env.example`):
```properties
GEMINI_API_KEY=your_actual_gemini_api_key_here
```
The Secrets Gradle plugin injects this key safely into `BuildConfig.GEMINI_API_KEY`.

---

## 📂 Project Structure
```
app/src/main/java/com/example/
├── MainActivity.kt               # Entry point with permission flows
├── ai/
│   ├── ArchanaAiService.kt       # Gemini REST client & persona fallback engine
│   ├── GeminiApiService.kt       # Retrofit definition
│   └── GeminiModels.kt           # Request/response data models
├── character/
│   ├── ArchanaCharacterView.kt   # Anime canvas, lip-sync, blinking & aura ring
│   └── CharacterExpression.kt    # Expression states
├── memory/
│   ├── ArchanaDao.kt             # Room DAO
│   ├── ArchanaDatabase.kt        # Room DB
│   ├── ConversationEntity.kt     # Chat history model
│   ├── MemoryEntity.kt           # Persistent user fact model
│   └── MemoryRepository.kt       # Repository
├── overlay/
│   └── FloatingOverlayService.kt # Draggable window overlay foreground service
├── permissions/
│   └── PermissionManager.kt      # Permission checks & intent helpers
├── phone/
│   ├── ArchanaAccessibilityService.kt # Accessibility for Back/Home/Recents
│   ├── CallReceiver.kt           # Incoming call broadcast receiver
│   └── PhoneActionHandler.kt     # App launchers & system control
├── settings/
│   ├── ArchanaPreferences.kt     # Preferences wrapper
│   └── AssistantMode.kt          # Mode enum (Normal, Friendly, Girlfriend, etc.)
├── ui/
│   ├── ArchanaViewModel.kt       # Core state management
│   ├── MainScreen.kt             # Primary Compose UI & quick actions
│   ├── MemorySheet.kt            # Memory management sheet
│   ├── PermissionsSheet.kt       # Android permissions sheet
│   ├── SettingsSheet.kt          # Personality & voice settings sheet
│   ├── WhatsAppReviewDialog.kt   # Safe message review dialog
│   └── theme/                    # Cyber anime M3 dark theme
└── voice/
    ├── ArchanaTtsManager.kt      # TextToSpeech manager with amplitude tracking
    └── ArchanaVoiceRecognizer.kt # SpeechRecognizer with wake word loop
```

---

## 🔒 Permissions Used
- `RECORD_AUDIO`: Voice input and speech-to-text recognition.
- `CALL_PHONE` & `READ_PHONE_STATE`: Initiating phone calls via voice commands.
- `SEND_SMS`: Preparing SMS messages.
- `CAMERA`: Flashlight / torch toggling.
- `SYSTEM_ALERT_WINDOW`: Floating character overlay.
- `BIND_ACCESSIBILITY_SERVICE`: Navigation shortcuts (Home, Back, Recents).
- `POST_NOTIFICATIONS`: Foreground service notifications.
